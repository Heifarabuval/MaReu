package com.heifara.buval.mareu2.service;

public class MeetApiServiceException extends Exception {
    public MeetApiServiceException() {super(); }
}
